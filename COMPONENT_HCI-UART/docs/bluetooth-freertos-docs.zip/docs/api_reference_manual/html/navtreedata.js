var NAVTREE =
[
  [ "Bluetooth Host Stack solution", "index.html", [
    [ "AIROC™ Bluetooth® Host Stack solution (for FreeRTOS)", "index.html", null ],
    [ "API Reference", "modules.html", "modules" ]
  ] ]
];

var NAVTREEINDEX =
[
"group__platform__cfg.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';