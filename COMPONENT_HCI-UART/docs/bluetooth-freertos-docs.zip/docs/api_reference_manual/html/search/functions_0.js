var searchData=
[
  ['cybt_5fplatform_5fconfig_5finit',['cybt_platform_config_init',['../group__platform__cfg.html#ga1ff2a9935b27efb9639974d6ddc1894a',1,'cybt_platform_config.h']]],
  ['cybt_5fplatform_5fset_5ftrace_5flevel',['cybt_platform_set_trace_level',['../group__platform__trace.html#gacff449b9b47250c93eb680a49129d9ec',1,'cybt_platform_trace.h']]]
];
