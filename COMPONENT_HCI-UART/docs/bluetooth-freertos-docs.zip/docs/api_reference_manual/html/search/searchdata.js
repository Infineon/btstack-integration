var indexSectionsWithContent =
{
  0: "abcdfhpstu",
  1: "c",
  2: "c",
  3: "bcdfhpstu",
  4: "c",
  5: "b",
  6: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Modules",
  6: "Pages"
};

