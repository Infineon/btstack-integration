var searchData=
[
  ['data_5fbits',['data_bits',['../structcybt__hci__uart__config__t.html#a7523d7315b657beda91ab9749b2e3539',1,'cybt_hci_uart_config_t']]],
  ['device_5fwake_5fpolarity',['device_wake_polarity',['../structcybt__controller__sleep__config__t.html#af610fc41d1a3984908fafcf00c7ec76e',1,'cybt_controller_sleep_config_t']]],
  ['device_5fwakeup_5fpin',['device_wakeup_pin',['../structcybt__controller__sleep__config__t.html#a27cadf5aa335e23250b095f0f213efec',1,'cybt_controller_sleep_config_t']]]
];
