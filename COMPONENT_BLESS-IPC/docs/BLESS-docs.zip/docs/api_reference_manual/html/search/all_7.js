var searchData=
[
  ['task_5fmem_5fpool_5fsize',['task_mem_pool_size',['../structcybt__platform__config__t.html#a31c8f2a35e4006fef44c65bb7dea5d4e',1,'cybt_platform_config_t']]],
  ['trace_5flevel',['trace_level',['../structcybt__platform__trace__cb__t.html#aff6cbe7223f753c87f870ff5cab4333d',1,'cybt_platform_trace_cb_t']]]
];
