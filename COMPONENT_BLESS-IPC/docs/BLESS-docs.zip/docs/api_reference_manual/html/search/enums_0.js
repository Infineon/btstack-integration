var searchData=
[
  ['cybt_5fexception_5ft',['cybt_exception_t',['../group__platform__cfg.html#gab887149c4cb3cd34b2984638c6c1aebb',1,'cybt_platform_config.h']]],
  ['cybt_5fhci_5ftransport_5ft',['cybt_hci_transport_t',['../group__platform__cfg.html#ga5f6850727c86459c4c6c11c84870d308',1,'cybt_platform_config.h']]]
];
