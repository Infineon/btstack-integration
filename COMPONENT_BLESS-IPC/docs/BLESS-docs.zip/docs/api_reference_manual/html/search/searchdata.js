var indexSectionsWithContent =
{
  0: "bcdfhpstu",
  1: "c",
  2: "c",
  3: "bcdfhpstu",
  4: "c",
  5: "c",
  6: "bd"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Modules"
};

