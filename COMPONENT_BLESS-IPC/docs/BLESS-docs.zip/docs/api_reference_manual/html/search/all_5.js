var searchData=
[
  ['parity',['parity',['../structcybt__hci__uart__config__t.html#ad4167be34fe428606a8a84feca8c1cc4',1,'cybt_hci_uart_config_t']]]
];
