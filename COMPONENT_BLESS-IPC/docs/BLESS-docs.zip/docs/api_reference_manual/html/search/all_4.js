var searchData=
[
  ['hci_5fconfig',['hci_config',['../structcybt__platform__config__t.html#a5ed1a8d945e1ed12a4181df867d41dc7',1,'cybt_platform_config_t']]],
  ['hci_5ftransport',['hci_transport',['../structcybt__hci__transport__config__t.html#a49e2aa2bba549df93cb113ecb293801f',1,'cybt_hci_transport_config_t']]],
  ['hci_5fuart',['hci_uart',['../structcybt__hci__transport__config__t.html#a906d2c4cc61e0cfdff53e7f004ac1396',1,'cybt_hci_transport_config_t']]],
  ['host_5fwake_5fpolarity',['host_wake_polarity',['../structcybt__controller__sleep__config__t.html#a593fd22a6c9987faaef084853b9dd3c6',1,'cybt_controller_sleep_config_t']]],
  ['host_5fwakeup_5fpin',['host_wakeup_pin',['../structcybt__controller__sleep__config__t.html#ad9491b731323d2e17b6836d26b7b238d',1,'cybt_controller_sleep_config_t']]]
];
