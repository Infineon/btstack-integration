var modules =
[
    [ "Debug UART Configuration", "group__debug__uart__cfg.html", "group__debug__uart__cfg" ],
    [ "Bluetooth Platform Configuration", "group__platform__cfg.html", "group__platform__cfg" ],
    [ "Bluetooth Platform Trace", "group__platform__trace.html", "group__platform__trace" ]
];